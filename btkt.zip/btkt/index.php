<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">PHP Example</a>
            </div>
        </nav>
    </header>

    <div class="container my-3">
        <form class="row" method="POST" enctype="multipart/form-data">
            <div class="col">
                <div class="mb-3">
                    <input type="file" accept=".txt" class="form-control" name="file">
                </div>
                <button type="submit" class="btn btn-primary" name="submit">Import database</button>
            </div>
        </form>

        <?php
        // Import dữ liệu từ file vào cơ sở dữ liệu
        if (isset($_POST['submit'])) {
            if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
                $fileTmpPath = $_FILES['file']['tmp_name'];
                $fileType = $_FILES['file']['type'];

                if ($fileType == 'text/plain') {
                    // 1. Kết nối với database
                    $server = "localhost";
                    $database = "db_trieu_tien_chung";
                    $username = "root";
                    $password = "";
                    $conn = new mysqli($server, $username, $password, $database);

                    if ($conn->connect_error) {
                        die('Kết nối thất bại: ' . $conn->connect_error);
                    }

                    // 2. Đọc file và insert vào database
                    $file = fopen($fileTmpPath, "r");
                    $successCount = 0;
                    $failCount = 0;

                    while (($line = fgets($file)) !== false) {
                        $data = str_getcsv($line, ",", '"');

                        if (count($data) == 3) {
                            $title = $conn->real_escape_string($data[0]);
                            $description = $conn->real_escape_string($data[1]);
                            $imageUrl = $conn->real_escape_string($data[2]);

                            // Kiểm tra xem bản ghi đã tồn tại chưa
                            $queryCheck = "SELECT COUNT(*) AS count FROM Course WHERE Title = '$title'";
                            $resultCheck = $conn->query($queryCheck);
                            $rowCheck = $resultCheck->fetch_assoc();

                            if ($rowCheck['count'] == 0) {
                                // Thực hiện insert
                                $queryInsert = "INSERT INTO Course (Title, Description, ImageUrl) VALUES ('$title', '$description', '$imageUrl')";
                                if ($conn->query($queryInsert) === TRUE) {
                                    $successCount++;
                                } else {
                                    $failCount++;
                                }
                            } else {
                                $failCount++;
                            }
                        }
                    }

                    fclose($file);
                    $conn->close();

                    // 3. Thông báo kết quả
                    echo "<div class='alert alert-info mt-2' role='alert'>
                            $successCount records inserted successfully, $failCount records inserted failed.
                          </div>";
                } else {
                    echo '<div class="alert alert-warning" role="alert">
                            Vui lòng tải lên file .txt!
                          </div>';
                }
            } else {
                echo '<div class="alert alert-danger" role="alert">
                        Lỗi tải file!
                      </div>';
            }
        }

        // Hiển thị dữ liệu từ cơ sở dữ liệu
        $server = "localhost";
        $database = "db_trieu_tien_chung";
        $username = "root";
        $password = "";

        $conn = new mysqli($server, $username, $password, $database);

        if ($conn->connect_error) {
            die('Connect failed: ' . $conn->connect_error);
        }

        $query = "SELECT * FROM Course";
        $result = $conn->query($query);

        echo '<div class="row row-cols-1 row-cols-md-2 g-4">';
        if ($result->num_rows > 0) {
            while ($course = $result->fetch_assoc()) {
        ?>
                <div class="col">
                    <div class="card">
                        <img src="<?= htmlspecialchars($course['ImageUrl']) ?>" class="card-img-top" alt="<?= htmlspecialchars($course['Title']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($course['Title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($course['Description']) ?></p>
                        </div>
                    </div>
                </div>
        <?php
            }
        }
        echo ' </div>';

        $conn->close();
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

</body>

</html>