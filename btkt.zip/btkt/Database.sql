-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2024 at 09:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_trieu_tien_chung`
--
CREATE DATABASE IF NOT EXISTS `db_trieu_tien_chung` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_trieu_tien_chung`;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `ID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `ImageUrl` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`ID`, `Title`, `Description`, `ImageUrl`) VALUES
(1, 'Laravel Programming', 'This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.', 'images/laravel.png'),
(2, '.NET Programming', 'This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.', 'images/dot-net.png'),
(3, 'Spring Boot Programming', 'This is a longer card with supporting text below as a natural lead-in to additional content.', 'images/spring-boot.png'),
(4, 'Angular Programming', 'This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.', 'images/angular.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Title` (`Title`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Database: `healthy_hub`
--
CREATE DATABASE IF NOT EXISTS `healthy_hub` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `healthy_hub`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1. danh mục bình thường\r\n2. danh mục review sản phẩm\r\n3. danh mục diễn dàn',
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`, `type`, `active`, `create_time`) VALUES
(1, 'Protein', 'Protein-powder supplements are among the most popular on the market today. They are said to aid recovery from workouts and aid muscle growth. They can also increase dietary protein intake, raise daily calorie intake and provide a sense of fullness for those looking to lose weight. There are many different types of protein – and the most popular are the dairy-based whey and casein. Whey is the most common of all the proteins and is the fastest digesting available. Other options include beef and egg proteins, as well as plant-based soy, brown rice and hemp. Plant-based sources are especially helpful for those who have milk allergies or follow vegetarian/vegan diets.', '78f4f259effedb0a085eefe34da04779.png', 1, 1, '2024-05-20 14:12:48'),
(6, 'Creatine', '', '664e322e093b848a4f5b5eb7ac15ea34.png', 1, 1, '2024-05-20 18:42:39'),
(12, 'Weight loss', '', 'c442c79d446d1326b8f69b7976fe89f5.png', 1, 1, '2024-05-21 16:40:35'),
(13, 'Best Rated Supplements', '', '', 2, 1, '2024-05-22 12:22:22'),
(14, 'Bé tiểu học (6-10 tuổi)', '', '3a57c1c28ead709cedb550b44cc703ce.webp', 3, 1, '2024-05-22 13:24:45');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `reply_to` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `content`, `reply_to`, `user_id`, `create_time`) VALUES
(22, 15, 'xin chào', NULL, 0, '2024-05-22 17:35:50'),
(23, 15, 'xin chào', NULL, 10, '2024-05-22 17:36:50'),
(24, 15, 'chào bạn', 23, 10, '2024-05-22 17:37:24'),
(25, 16, 'aaaaa', NULL, 0, '2024-05-22 18:16:43'),
(26, 16, '131331', NULL, 0, '2024-05-22 18:17:33'),
(27, 16, '131331', NULL, 0, '2024-05-22 18:17:53'),
(28, 16, '13123131', NULL, 0, '2024-05-22 18:17:58');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` longtext NOT NULL,
  `star` float DEFAULT NULL,
  `user_id` int(11) NOT NULL COMMENT 'người tạo bài viết, có thể là người dùng đăng bằng hoặc amdin tự tạo bài',
  `active` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0: chờ xét duyệt\r\n1: đã duyệt\r\n2: từ chối duyệt',
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `title`, `image`, `description`, `content`, `star`, `user_id`, `active`, `create_time`) VALUES
(7, 1, '100% Whey Protein', '1fa233394ff71322891bd5c6ad72f705.jpg', '', '<p>1</p>', 0, 1, 1, '2024-05-21 18:32:36'),
(8, 1, 'Beyond Raw Re-Built Mass XP', '9bd64982560ff0ae086e96ba684174a0.jpg', '1', '<p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Beyond Raw Re-Built Mass XP is a weight gainer manufactured by GNC. It is designed to help the “advanced bodybuilder” gain “mass”, “power” and “size”.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Each serving provides 60g of protein, which derives from whey isolate, whey concentrate, calcium caseinate and hydrolyzed whey peptides. One portion also provides 140g of carbohydrates, 9g of fat, 4g of sugar and 880 calories.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">The product also contains 5g of creatine, which is said to help increase muscle energy during exercise. In addition, the 16.1g of branched-chain amino acids (BCAA) could ease muscle soreness and speed up recovery.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Beyond Raw Re-Built Mass XP is gluten-free.</span></p><p></p>', 3, 1, 1, '2024-05-22 05:32:31'),
(9, 13, 'T Hero Review', '01ee8b284c7f6cc4bb3baa159d7812f2.jpg', '', '<h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Does T Hero Really Boost Testosterone Production/Testosterone Levels?</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Once you pass the age of 25, Testosterone levels begin to decline. This is something that affects others more severely, but it will affect everyone. This can cause major issues to both your energy levels, muscle mass, and sex drive, not to mention the effects all of this can have on your mental health. Luckily there’s plenty of clever people out there that have put together testosterone boosting supplements that use natural ingredients to boost your bodies ability to natural produce testosterone.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">The question is, how is anyone supposed to figure out what’s actually worth your money when all of these brands claim to be the best? Well that’s where we come in, combining our expert industry knowledge with a fantastic research team in order to sort the very best from the very worst.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Well then you’re probably wondering what we think of T Hero, and for those looking for a quick answer we would not recommend this supplement. T Hero isn’t a terrible supplement by any stretch of of the word, containing some fantastic ingredients that are clinically proven to boost testosterone levels, it’s just that there’s similar products that take things to the next level, such as one of our favourites Testofuel.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Let’s get on with the article, but for those interested you can </span><a href=\"https://www.roarambition.com/en-eu/testofuel\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"background-color: transparent; color: rgb(232, 131, 14);\">Browse Testofuel Deals Here.</a></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Ingredients In T Hero (Ingredients Breakdown)</span></h2><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Ashwagandha Extract 600mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This ingredient has a long and storied history of use, particularly in traditional Indian medicine where it’s use can be traced back as far as 6000BC. It was mostly used a a general tonic, but was noted for it’s effects as an aphrodisiac and stimulant. More modernly it’s known as an adaptogen, with some thinking it’s able to reduce swelling, calm the brain, lower blood pressure and, of course, increase testosterone levels, but some dispute these claims.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">That being said, the clinical data is largely positive for ashwagandha extract as a testosterone booster, such as a randomized, double-blind study we found which took 43 men and treated them with either 300mg of ashwagandha extract or placebo. The findings of this study revealed that although an increase in testosterone levels was found in the intervention group, there was no notable difference in stress hormone levels, fatigue/ vigor, or sexual well-being [1].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">As promising as it is to hear of an increase in free testosterone, it’s clear more testing is required to fully understand the mechanisms with which this is achieved, as many of the desired effects of increased testosterone levels were not observed.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Shilajit Extract (20% Fulvic Acid) 500mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Shilajit, also called mineral pitch, contains fulvic acid and many other minerals. There are numerous possible benefits of shilajit. Taking it as a powder or supplement may help boost brain function, slow the aging process, increase fertility, and more. More modern times have people claiming shilajit can prevent or slow Alzheimer’s disease, raise testosterone levels and even treat chronic fatigue syndrome, though not all of said claims are backed by scientific research.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">One scientific study carried out focused on testing sixty-three active men using this extract in order to examine the results. The verdict of this test concluded a retention of maximal muscular strength following the fatiguing protocol[2]. This also elicited favourable muscle and connective tissue adaptations. Overall this is a beneficial extract towards seeking muscle retention based on a similar dosage examination on a test group.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Diindolylmethane (DIM) 100mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Diindolymethane is a biproduct of a chemical called Indole-3-carbinol which is most commonly found in cruciferous vegetables such as brocoli and cauliflower. Its use in testosterone boosters is because it’s thought to reduce estrogens effects, though there’s some contradicting evidence for this.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">We found a clinical trial that states diindolymethane leads to a decrease in sperm quality as well as cell death in the reproductive system [3] so it seems we’re going to need further testing to prove whether or not this is going to be useful. The data for Indole-3-carbinol is much more clear cut for limiting estrogen production, leaving us wondering why they didn’t just include that?</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Boron 5mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Boron is known as a trace mineral due to the small amount found in the human body. It is also known to be useful towards growth and bone maintenance, beneficial towards healing and also impacting the absorption of other important essential minerals like magnesium and vitamin D. Boron is quite extensive towards it’s beneficial properties in general health but what effect does it have on testosterone production?</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">We discovered a review examining the effects Boron has on human health and the extensive collection of positive data led us to a clever article title “Nothing Boring About Boron”. This study includes four studies directly related to Borons effects on sex steroid hormones, all of which had highly positive reviews. One such study demonstrated the doubling of testosterone levels whilst testing with people who had a low boron diet [4]. Like we discussed with the previous extract small doses are unlikely going to make any immediate changes and we must keep an open mind when learning about the advantages of certain natural ingredients.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Black Pepper Extract – 10mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">There’s a distinct, biting flavour to black pepper that it seems to hold exclusive rights to, and the cause of this taste is Piperine. This alkaloid is also the main cause of black peppers super power – the ability to increase the bioavailability of nutrients, or to put it more simply – the ability to increase the amount of nutrition you can absorb. It doesn’t do a whole lot on it’s own then, but pair it with a bunch of ingredients that all boost testosterone and you’ll end up with a far more effective formula overall.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Verdict</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">So with the review of T-Hero coming to a close we’ve learnt a lot from what this product can offer. The insights into how different extracts can be greatly beneficial towards your health. But overall T-Hero fails to deliver a truly amazing product mainly because of the small amount of ingredients resulting in diminishing effects. Low dosages aligned with a small set of ingredients fails to offer true value for money. There is one other product that does offer much better value and that product is called Testofuel. These findings are based on extensive research to discover the best results from a range of supplements.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Our recommendation – TestoFuel</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Testofuel’s formula excels when it comes to enhancing your testosterone levels, offering a quicker and more efficient result for those seeking immediate effects. There’s simply a lot more to it, giving you better value for your money as well thanks to not only more ingredients, but ingredients that are better proven by clinical data.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">TestoFuel is an excellent alternative focusing heavily on the importance of testosterone levels, performance and strength. Extracts include Vitamin D3 &amp; K2, Magnesium, Zinc, Oyster Shell, Boron etc. Vitamin D helps your body absorb calcium in result helps with bone strength, muscle functionality and assisting the immune system against invading bacteria and viruses[5]. Vitamin K (MK-7) has health-beneficial effects in cardiovascular disease, cancer, Alzheimer’s disease and diabetes. Magnesium is an abundant mineral in the body that regulate diverse biochemical reactions in the body including protein synthesis, muscle and nerve function and bloody pressure regulation[6].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">A vital component not used in T-Hero is D-Aspartic acid, an amino acid that plays a significant role in controlling both growth hormones and testosterone levels. It also triggers the release of a hormone known as the luteinizing hormone. One thing often overlooked with this ingredient is it’s crucial role in enhancing sperm quality. One clinical trial demonstrated that just 90 days of supplementing with D-Aspartic acid led to a 30-60% increase in testosterone levels and a 60-100% improvement in sperm count [7].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Another vital mineral not found in T-Hero is Zinc. Zinc is a vital trace element for normal function of the living system. In men, zinc is involved in various biological processes, an important function of which is as a balancer of hormones such as testosterone. Studies have also proven the importance of zinc while examining test subjects and their deficiency in zinc. Tests have concluded a reduction in testosterone levels and that zinc supplementation improves testosterone production[8].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">As you can see, although T-Hero is certainly a competent testosterone boosting supplement, there are many benefits to using TestoFuel. Both supplements provide some essential elements but overall TestoFuel provides a much greater response when seeking testosterone production. For those seeking muscle growth and a greater level of testosterone production from supplements look no further as our research has demonstrated which offers a better result. For those seeking a change in workout performance and muscle growth TestoFuel covers all the criteria towards improving not just your physical health but also overall mental health/ability.</span></p><p></p>', 0, 1, 1, '2024-05-22 12:23:07'),
(10, 13, 'Swolverine Therm Reviews', '588118f84d4bdabdf72edd5786664cd0.webp', 'Does Swolverine actually help decrease body fat?', '<p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">First of all let’s just give credit for what is without a doubt the best brand name we’ve ever seen. It’s the kind of thing you can imagine everyone said no to, because it’s just so stupid, but it’s extremely charming because of that. Unfortunately that’s about where the compliments end, as Therm is a pretty terrible supplement for reducing body weight.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Ofcourse we’ll go into more detail, but it almost comes across as though it’s throwing everything at the wall and hoping something sticks, with 20 ingredients in total. It’s either that or perhaps they’re hoping that by providing so many ingredients, they’ll attract less knowledgable customers who think more is better. We can’t say for sure, all we can truly say is that we do not recommend this product at all, and would advise you go elsewhere for your weight loss needs.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">With a name like swolverine it seems their main target demographic would be regulars at the gym, so if you’re looking for something that can help you lose weight and supports your fitness journey, then we highly recommend Instant Knockout Cut instead. It was developed alongside MMA coaches as a way to help the fighters meet weigh-in goals without sacrificing strength, and it’s so effective it’s still used to do this day. It has a much more focused ingredients list that hits every aspect of weight loss, from reducing sugar cravings to improving metabolism and everything in between.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">With that said let’s get into the review proper and see exactly where this fat burning supplement fails.</span></p><p><a href=\"https://www.instantknockout.com/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"color: rgb(232, 131, 14); background-color: transparent;\">Shop Instant Knockout Cut Deals Here</a></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Ingredients Breakdown</span></h2><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Vitamin B6 – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">B vitamins are a common ingredient in many weight loss supplements, as they’re characterised by the roles they play in all aspects metabolism. Vitamin B6 actually plays a role in over 100 enzyme reactions [1], and has been studied for it’s potential links to obesity. It’s been proven to have some links as many studies have found supplementation to help, such as one study we found in which the researchers concluded as such: “Vitamin B6 supplementation may be effective at improving body composition and biochemical factors associated with obesity [2].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Overall a strong start, though noting the dosage here is actually very high. This won’t cause problems but looking at it as a formula, it’s space that could be better used elsewhere. As we’ll soon see, the dosing is all over the place with Swolverine Therm.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Iodine – 150mcg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Iodine is often discussed in some corners on the internet as something that can supposedly improve the body’s metabolic process/ promotes a healthy metabolism. You can see some logic here as Iodine is an essential trace element involved in thyroid health, but the reality is that the data does not support these claims. There are some promising results here and there, but overall the data is still very inconclusive. This can be seen in this review we found which tested data on urinary iodine to see if there was a link with the levels and obesity. In the conclusion of the paper the researchers say: “data on UI excretion in overweight/obese children are divergent, as both increased and reduced UI levels are reported in overweight/obese children compared to normal-weight controls”. [3]</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Chromium – 100mcg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This is a very interesting essential trace mineral with a rather tragic recent history. Basically we get Chromium from most food sources, but it’s been in decline in recent years due to modern agricultural practices, and this deficiency has strong links to obesity. The data is conflicting however, as this review we found states: “The effects of Chromium on body composition are controversial but are supported by animal studies” [4].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Unfortunately whether helpful or not, 100mcg isn’t going to do a whole lot.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Guarana (33% extract providing 100mg Caffeine) – 300mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Probably the most effective ingredient in this entire formula, as it’s one of the few that are not only clinically proven to help decrease body fat but is actually dosed effectively. Essentially caffeine is very helpful for people looking to increase lean body mass, with three powerful effects; suppress energy intake/ suppress appetite [5], increasing basal metabolic rate [6], and increasing workout intensity [7].</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">The dosage her is effective as we said, though is definitely on the lower end of the spectrum still. That said, we’ll take it as a win as it’s likely the last bit of positivity for a while.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Cocoa Extract – 50mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">It might sound too good to be true that cocoa could help with obesity, and although there’s some support evidence, the data is ultimately still inconclusive so it likely is. We found a review that took 19 clinical trials and analysed their data, and they concluded as such: “more studies are needed to investigate the impact of cocoa polyphenol intake on obese adults, as the results of the included studies are still inconclusive” [8]</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Yerba Mate Powder – 50mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This is an interesting ingredient to see in a weight loss supplement as it’s actually fairly positively received when looking at the clinical data. The reason you don’t tend to see it in many weight loss supplement however, is that it requires a very large amount of space in the supplement for what is ultimately a fairly fine effect that could easily be replicated with half the amount of something like L-Theanine and EGCG from green tea. This can be see in this study we found that had very promising results, supplementing 3150mg of yerba mate powder [9]</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Green Tea Leaf – 50mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">A sight for sore eyes here is one of the most well recognised and positively received ingredients for weight loss. We all know someone who drinks green tea and swears by it, and it’s had a lost of positive results in clinical testing. The extract here is EGCG, the most abundant flavinoid present in green tea. With fear of repeating ourselves, it’s the low dosage that is the issue. This fantastic review shows positive results being observed from a dosage of 500mg plus [10], a whopping ten times more than is present in Therm.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Garcinia Cambogia Leaf – 125mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This ingredient rose in popularity about 15 years ago due to promising animal testing, but once human intervention studies were conducted most people moved on and forgot about it. We found a systematic review of human intervention studies so we’ll let them sum it up for us: “The evidence from RCTs suggest the Garcinia extracts generate weight loss on the short term. However, the magnitude of this effect is small, is no longer statistically significant when only rigorous RCTs are considered, and it’s clinical relevance seems questionable” [11].</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Chitosan – 125mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">We’re on the quick fire round here so fasten your seatbelts. Chitosan is a weight loss supplementing with some positive results, though it’s use is considered controversial as these results are considered erratic. Overall it seems unreliable with the amount of conflicting data, but even the positive results are small, such as this study that did find increased fat burning but concluded this was not statistically significant. The dosage used in this trial was 3g per day [12], leaving much to be desired but even if it was dosed correctly, there wouldn’t be much room for anything else.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Gymnema Sylvestre Leaf Powder – 50mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">All of the studies we could find for this ingredient were animal studies, which leaves us baffled as to why it’s included here. That said there’s some promising results but again, the dosing is just far too low. To give a generous example, we’ll use one of the more promising trials which dosed 200g rats with 20g of the stuff [13], so 50mg on a human is completely negligible.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Banaba Leaf – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Banaba leaves have promising animal studies but we were unable to find human intervention studies, such as it being shown to lower blood sugar levels in rabbits, with them receiving 100mg tablets of the stuff [14]. Not enough data, not enough dosed.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Calcium Pyruvate – 50mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">We found a great systematic review for this one that took 6 individual randomly controlled trials and simply concluded “The evidence from randomised clinical trials does not convincingly show pyruvate is efficacious in reducing body weight” [15]. A very formal way of saying it doesn’t work.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Apple Cider Vinegar – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Slightly less prominent than green tea as, it’s results are controversial, but it’s quite likely most people reading this will have known someone swear by apple cider vinegar. It was a fad for sure, and we found one review of 13 human intervention trials and 12 animal intervention trials that summed things up very well: “The evidence for the health effects of apple cider vinegar is insufficient” [16].</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Grapefruit Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">When it comes to this one, we’re unsure about it. The data is almost entirely on grapefruit juice, and there are many things that can change as it’s processed into a powder, similar to how things change when fruit juice is consumed rather that the fruit itself. That said, again, any positive results typically have people drinking around 500ml per day, so 25mg of whatever it is that’s being extracted and powdered, is unlikely to have much of an effect at all.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Coleus forskohlii Root Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This one is just a dud, with some promising results but very few. We found a 12 week trial that had the patients take 250mg of CF extract twice a day (so 500mg, 20 times what is present here) and concluded “Results suggest that CF does not appear to promote weight loss” [17].</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">White Willow Bark Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This is a really interesting one as it’s quite widely used but really, there’s no data supporting it that isn’t anecdotal. We found a study looking into the safety of white willow bark which states the following: “Willow bark extracts also are widely used in sports performance and weight loss products presumably because of anti-inflammatory and alagesic activities, although no human studies have been published that specifically and directly document beneficial effects.” [18].</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Uva Ursi Leaf Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Also known as the Bearberry, Uva Ursi leaf is another ingredient with very little scientific backing for it’s inclusion in a weight loss supplement. Despite finding a lot of talk regarding it’s use in weight loss supplements, the only trials we could find on this ingredient were testing it’s use as an anti-inflammatory and antioxidant. Once again though the dosage is letting us down tremendously anyways, with it being testing from as low as 175mg, three times per day.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Juniper Berry Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Another ingredient here with great promise but just not quite enough data to say for sure that it will be very useful at all. We found a trial showing it’s promise for helping to regulate diabetes and obesity markers [18]. However positive the results, this was a study on the effects on rats and as such we’re not really 100% sure if it will have a similar effect on humans, and we don’t know what kind of dosage might be effective. We’d wager it’s more than 25mg, but we can’t say for sure ofcourse.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Buchu Leaf Powder – 25mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Another ingredient, another waste of time. Surprising we actually found a review looking at what was described as “scarce” pharmacological research on buchu leaf extracts and they summed it up best: “health claims for buchu products need to be substantiated by randomized, double-blind and placebo-controlled studies. Only then can they be promoted for their true therapeutic potential” [19].</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Cayenne Pepper Fruit – 10mg</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">It’s disappointing to see Cayenne pepper here, almost like seeing a friend that’s really down on their luck or have maybe fallen in with the wrong crowd. Cayenne pepper is a great ingredient for weight loss, and you’ll find it in pretty much all of the best fat burners out there. How it works is it boosts metabolism by increasing thermogenic activity in the body, which is essentially the process with which our muscles burn calories to produce heat. Therefore by increasing thermogenic activity, you increase energy expenditure.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This is all thanks to capsaicinoids that are contained within cayenne peppers, which is also responsible for the distinct flavour and spice that they’re known for. Usually you’ll either see “Cayenne pepper extract” and it’ll be dosed around 10mg, or you’ll see “Cayenne pepper fruit” and it’ll be dosed around 100mg. This is because essentially the first is a concentrated dose of capsaicinoids, whereas the second is a slightly less space-efficient but possibly cheaper option. Here we have the fruit with the lower dosage, so once again, the ingredient is improperly dosed.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">This is a shame as once again, it’s a fantastic ingredient, and has a lot of clinical backing. For example we found a study that showed an almost 6% (5.91) increased reduction in body fat after a 12 week period with just 4mg daily of a capsaicinoid extract [20], showing how potent this ingredient can be.</span></p><h2><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Verdict</span></h2><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">Despite loving the brand name we’re very disappointed with this weight loss supplement. It’s something we just can’t recommend, with one or two good ideas overshadowed by some ill-advised attempt to flood the supplement with anything that </span><em style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">might</em><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\"> help, with almost no care for the scientific literature.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(44, 47, 52);\">If you want a weight loss product that will actually work then look no further than Instant Knockout Cut. A focused formula with a clear goal in mind that is very competently achieved, Instant Knockout Cut is what we would currently consider the best in the market. You have glucomannan for appetite suppression, caffeine and cayenne for a boost to resting metabolism thanks to their thermogenic activity, a nice blend of useful vitamins and even some specialised ingredients such as green tea extract and L-theanine to help maximise body fat burned.</span></p><p></p>', 0, 1, 1, '2024-05-22 12:24:27'),
(13, 14, 'xin chào', '', '', '<h5><strong style=\"color: var(--custom-heading-color,#262626); background-color: rgb(255, 255, 255);\">Kinh nghiệm tổ chức tiệc liên hoan cuối năm cho bé sắp tới</strong></h5><p><span style=\"color: rgb(0, 0, 0); background-color: rgb(255, 255, 255);\">Việc tổ chức lễ tổng kết cần lưu ý đến cách bố trí chỗ ngồi. Các con sẽ được phân chia theo mỗi lớp. Với sự phân công cô giáo chủ nhiệm sẽ ổn định chỗ ngồi cho các con. Bên cạnh đó khu vực dành cho phụ huynh cần được chú trọng. Đảm bảo đủ số lượng và không gian để quan sát sân khấu. Ngoài ra những tiết mục văn nghệ cần được tập dợt kỹ càng. Tránh các trường hợp quên bài hoặc sự cố trên sân khấu. Phần thiết bị âm thanh ánh sáng cũng cần được kiểm tra kỹ lưỡng. Và sau cùng là mc </span><span style=\"color: rgb(232, 83, 136); background-color: rgb(255, 255, 255);\">chú hề hoạt náo</span><span style=\"color: rgb(0, 0, 0); background-color: rgb(255, 255, 255);\"> cần nắm rõ các phần có trong buổi lễ.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);\"><img src=\"https://cdn-together.hellohealthgroup.com/2024/05/1715845697_6645ba41ba1f91.76595247\" alt=\"Kinh nghiệm tổ chức tiệc liên hoan cuối năm cho bé sắp tới\"></span></p>', 0, 10, 1, '2024-05-22 15:04:04'),
(15, 14, 'Cha mẹ nhớ kĩ! Tuyệt đối đừng bao giờ nói dối khi dạy con', '', NULL, '<h5></h5><p><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">Là cha mẹ, chúng ta thường đặt ra câu hỏi: &quot;Làm thế nào để dạy con trở thành người trung thực?&quot; Đó không chỉ là việc nói với con cái về việc nói dối là không tốt, mà còn là hành động mẫu mực của chính bản thân chúng ta.</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">---------------------</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">💝</span><strong style=\"background-color: rgb(255, 255, 255); color: inherit;\">Chào thành viên mới - Tặng Evoucher GotIt 50k </strong><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">mua sắm trên nhiều sàn thương mại điện tử như </span><strong style=\"background-color: rgb(255, 255, 255); color: inherit;\">Shopee, Lazada, CGV, Grab, Vinmart,</strong><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">…</span></p><p><span style=\"background-color: rgb(255, 255, 255); color: inherit;\">Nhấn </span><span style=\"background-color: rgb(255, 255, 255); color: rgb(232, 83, 136);\">đăng ký</span><span style=\"background-color: rgb(255, 255, 255); color: inherit;\"> để hỏi bác sĩ trực tuyến miễn phí và không bỏ lỡ những video hữu ích khác về sức khỏe và tư vấn lối sống nhé!</span></p><p><a href=\"https://www.marrybaby.vn/community/be-tieu-hoc-6-10-tuoi/dinh-duong/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"background-color: rgb(250, 250, 250); color: rgb(62, 63, 88);\">Dinh dưỡng</a></p><p><a href=\"https://www.marrybaby.vn/community/be-tieu-hoc-6-10-tuoi/moc-phat-trien/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"background-color: rgb(250, 250, 250); color: rgb(62, 63, 88);\">Mốc phát triển</a></p><p><a href=\"https://www.marrybaby.vn/community/be-tieu-hoc-6-10-tuoi/cham-soc/\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"background-color: rgb(250, 250, 250); color: rgb(62, 63, 88);\">Chăm sóc</a></p><p><a href=\"https://www.marrybaby.vn/community/#\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"background-color: rgb(250, 250, 250); color: rgb(62, 63, 88);\">+2 chủ đề khác</a></p><a href=\"https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Freel%2F970837031122615&autoplay=1&show_text=false&t=0&width=669&height=376\">https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Freel%2F970837031122615&autoplay=1&show_text=false&t=0&width=669&height=376</a><p></p><p></p>', NULL, 10, 1, '2024-05-22 17:00:44'),
(16, 14, 'Bệnh án, sức khỏe của Ủy viên Bộ Chính trị, Ban Bí thư là Tối mật 99', '', NULL, '<h2><strong style=\"color: rgb(37, 37, 37);\">Hồ sơ bệnh án, thông tin, kết quả khám bệnh, chữa bệnh, kiểm tra sức khỏe của các Ủy viên Bộ Chính trị, Ban Bí thư Trung ương Đảng là thông tin Tối mật.</strong></h2><p><span style=\"color: rgb(37, 37, 37);\">Phó Thủ tướng Trần Hồng Hà vừa ký quyết định ban hành Danh mục bí mật nhà nước lĩnh vực y tế với hai cấp độ tối mật và mật.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Trong đó, bí mật nhà nước độ Tối mật gồm hồ sơ bệnh án, thông tin, kết quả khám bệnh, chữa bệnh, kiểm tra sức khỏe của các Ủy viên Bộ Chính trị, Ban Bí thư Trung ương Đảng.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Bí mật nhà nước độ Mật hai nhóm. Cụ thể, số người mắc, người chết do bệnh truyền nhiễm nguy hiểm mới phát sinh chưa rõ tác nhân gây bệnh chưa được Bộ Y tế công khai.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Tên, nguồn gốc, độc lực, khả năng lây lan, đường lây của các tác nhân gây bệnh truyền nhiễm mới phát hiện, chưa xác định được có liên quan đến sức khỏe, tính mạng con người, ảnh hưởng đến sự phát triển kinh tế - xã hội chưa được công khai.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Quyết định này có hiệu lực thi hành kể từ ngày 22-5 và thay thế Quyết định 1295/2020 của Thủ tướng ban hành Danh mục bí mật nhà nước lĩnh vực y tế.</span></p><p><span style=\"color: rgb(37, 37, 37);\">So với Quy định 1295 thì quy định mới lần này đã đưa &quot;tên, nguồn gốc, độc lực, khả năng lây lan, đường lây của vi sinh vật mới phát hiện chưa xác định được có liên quan đến sức khỏe, tính mạng con người, ảnh hưởng lớn đến sự phát triển kinh tế - xã hội&quot; ra khỏi mức độ Tối mật.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Đồng thời cũng bỏ một số danh mục ra khỏi bí mật nhà nước độ Mật. Gồm, mẫu vật, nguồn gen, phương án bảo vệ an ninh, an toàn vùng trồng dược liệu số lượng còn ít hoặc bị đe dọa tuyệt chủng.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Quy mô, phân bố, số liệu về dân số tại các vùng biên giới, hải đảo; nguồn nguyên liệu, thông số kỹ thuật sản xuất thuốc cổ truyền, thuốc sinh học quý hiếm thuộc dự án nhà nước, chương trình sản phẩm quốc gia chưa công khai.</span></p><p><span style=\"color: rgb(37, 37, 37);\">Tên, địa chỉ phòng xét nghiệm an toàn sinh học cấp III đã được Bộ Y tế cấp giấy chứng nhận mất điều kiện đảm bảo an toàn sinh học.</span></p><p></p>', NULL, 10, 1, '2024-05-22 17:39:13'),
(17, 12, 'Bài viết của Chung', 'c222517661b3d56795db2e7a64e606ea.png', '', '<p>các cháu sẽ ko pay nổi đâu , lỗi ở đâu thì chịu</p>', 4.5, 1, 1, '2024-10-08 10:23:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 2 COMMENT 'phân loại user:\r\n1. admin\r\n2. người dùng',
  `create_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `create_time`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 1, '2024-05-12 22:55:57'),
(7, '123', '123@gmail.com', '202cb962ac59075b964b07152d234b70', 2, '2024-05-21 13:44:28'),
(10, 'user', 'user@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', 2, '2024-05-22 13:09:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Database: `heathy_hub`
--
CREATE DATABASE IF NOT EXISTS `heathy_hub` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `heathy_hub`;
--
-- Database: `my_personal_contacts`
--
CREATE DATABASE IF NOT EXISTS `my_personal_contacts` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `my_personal_contacts`;

-- --------------------------------------------------------

--
-- Table structure for table `my_contacts`
--

CREATE TABLE `my_contacts` (
  `id` int(11) NOT NULL,
  `full_names` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `contact_no` varchar(75) NOT NULL,
  `email` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `my_contacts`
--
ALTER TABLE `my_contacts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `my_contacts`
--
ALTER TABLE `my_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"db_trieu_tien_chung\",\"table\":\"course\"},{\"db\":\"db_trieu_tien_chung\",\"table\":\"Course\"},{\"db\":\"db_trieu_tien_chung\",\"table\":\"records\"},{\"db\":\"healthy_hub\",\"table\":\"users\"},{\"db\":\"healthy_hub\",\"table\":\"posts\"},{\"db\":\"healthy_hub\",\"table\":\"comments\"},{\"db\":\"healthy_hub\",\"table\":\"categories\"},{\"db\":\"my_personal_contacts\",\"table\":\"my_contacts\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-10-25 07:22:27', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
